// Node
struct Node {
  int data;
  Node *prev, *next;
  // print this node
  void show();
};

class LinkList {
public:
  // constructor
  LinkList();

  ~LinkList();

  // push a node into the list at the head.
  void pushBack(Node *);

  // push a node with a data.
  void pushBack(int);

  // erease a node from the list.
  void erease(Node *);

  // erase a node by data.
  void erease(int);

  // get the first node by given data
  Node *find(int);

  // show all nodes
  void show();

  int length() const;

  const Node *head() const;

private:
  // the head node.
  // do not have illegal data.
  // do not in the circular list.
  // the prev of _head will always be nullptr.
  Node *_head;
  int _length;
};
