#include "LinkList.h"
#include <iostream>
using namespace std;
void testJosephus() {
  LinkList l;
  for (int i = 1; i <= 41; i++) {
    l.pushBack(i);
  }
  cout << "initial status:" << endl;
  l.show();
  cout << "-------------------" << endl;
  auto now = l.find(1);
  int count = 1;
  int times = 0;
  while (l.length() > 1) {
    now = now->next;
    if (now == l.head()) {
      now = now->next;
    }
    if (count++ == 3) {
      auto duplicateNode = now;
      now = now->next;
      cout << "The No. " << ++times << " will be killed: ";
      duplicateNode->show();
      l.erease(duplicateNode);
      count = 1;
      // cout << "Now remain: " << endl;
      // l.show();
      // cout << "----------------------" << endl;
    };
  }
  cout << "The last one: ";
  l.show();
}

int main() {
  LinkList l;
  for (int i = 0; i < 10; i++)
    l.pushBack(i);
  l.show();
  // remove the odds
  for (int i = 0; i < 10; i += 2) {
    l.erease(i);
  }
  cout << endl;
  l.show();

  system("clear");

  testJosephus();
  return 0;
}
